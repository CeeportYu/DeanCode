package model;

public class Bike {

}
